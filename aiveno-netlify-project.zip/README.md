
Aiveno Netlify Project

Steps:
1. Upload this project to GitHub
2. Connect repo to Netlify
3. Add environment variable:
   GEMINI_API_KEY = your_api_key_here
4. Deploy

Your app will work at:
https://your-site.netlify.app
